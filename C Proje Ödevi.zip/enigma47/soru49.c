#include <stdio.h>

int main() {
    char kelime[11];
    printf("10 karaktere kadar kelime giriniz:");
    scanf("%d", kelime);
    printf("%s", kelime);
    return 0;
}