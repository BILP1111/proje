#include <stdio.h>

int main() {
    int kenar = 0;
    printf("Karenin bir kenarini giriniz:");
    scanf("%d", &kenar);
    printf("%d", kenar * kenar);
    return 0;
}