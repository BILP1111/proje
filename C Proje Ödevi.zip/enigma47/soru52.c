#include <stdio.h>

int main() {
    char kelime[200];
    printf("kelime giriniz:");
    scanf("%d", kelime);
    printf("karakter sayisi: %d", strlem(kelime));
    return 0;
}