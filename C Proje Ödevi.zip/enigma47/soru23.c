#include <stdio.h>

int main() {
    for(int i = 1; i<=25; i++) {
        printf("%d", i);
    }
    for(int i = 25; i>=1; i--) {
        printf("%d", i);
    }
    return 0;
}