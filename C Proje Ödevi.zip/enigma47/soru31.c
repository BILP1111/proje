#include <stdio.h>

int main() {
    int sayi = 0;
    while(sayi > 0) {
        printf("Sayi giriniz:");
        scanf("%d", &sayi);
        printf("%d", sayi);
    }
    return 0;
}