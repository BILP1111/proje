#include <stdio.h>

int main() {
    int yari_cap = 0;
    printf("Yari cap giriniz:");
    scanf("%d", &yari_cap);
    printf("%d", (3.14 * yari_cap * 2));
    return 0;
}