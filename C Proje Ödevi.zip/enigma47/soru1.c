#include <stdio.h>

int main() {
    printf("C Programlama dunyasina hos geldiniz.");
    return 0;
}