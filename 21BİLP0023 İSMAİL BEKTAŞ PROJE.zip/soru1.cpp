#include <stdio.h>
main()
{
	printf("C Programlama Dunyasina Hos Geldiniz");
	return 0;
}

