#include <stdio.h>
#include <conio.h>
 
main(void)
{
      char kelime[10];
 
      printf("\n Kelimeyi girin : ");
      gets(kelime);
   
      printf("\n Girilen Kelime : %s",kelime);
      getch();
}
