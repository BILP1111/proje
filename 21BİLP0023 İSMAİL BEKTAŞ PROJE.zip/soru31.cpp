#include <stdio.h>
#include <conio.h>
 
 main(void)
{
 int sayi = 0;
 
 while( sayi >= 0)
 {
  printf("\nSayi? : ");
  scanf("%i",&sayi);
 
  printf("%i sayisini girdiniz.",sayi);
 }
}
