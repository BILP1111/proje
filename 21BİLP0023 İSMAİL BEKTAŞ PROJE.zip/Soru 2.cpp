#include <stdio.h>
#include <conio.h>
 
 main(void)
{
 int sayi = 0;
 
 
 
 printf("\n Bir sayi giriniz: ");
 scanf("%i",&sayi);
 
 
 printf("\n Girdiginiz sayi %i'dir",sayi);
 
 getch();
}
